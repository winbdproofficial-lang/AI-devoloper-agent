# Agent module

This folder documents how an automated development agent should interact
with this repository.

- **AGENTS.md** — the binding rules the agent must follow (secrets handling,
  code-change discipline, reporting format). Read this first.
- Any agent-specific configuration, prompts, or tool definitions should live
  in this folder as the project grows, rather than being scattered across the
  codebase.

## Adding a new agent capability

1. Document the capability and its required environment variables here.
2. Add the variable name (not the value) to `../.env.example`.
3. Update `../README.md` if it changes how a contributor sets up the project.
